import { useState, useEffect } from 'react'

export default function Header({ phase, parsedProfile, onReset }) {
  const [time, setTime] = useState(() => new Date().toLocaleTimeString('en-US', { hour12: false }))

  useEffect(() => {
    const t = setInterval(() => {
      setTime(new Date().toLocaleTimeString('en-US', { hour12: false }))
    }, 1000)
    return () => clearInterval(t)
  }, [])

  const dotColor = phase === 'running'
    ? 'var(--california-gold)'
    : phase === 'results'
    ? 'var(--green-signal)'
    : '#4a5568'

  const statusLabel = phase === 'input' ? 'Ready' : phase === 'running' ? 'Analyzing' : 'Complete'

  return (
    <header style={{
      borderBottom: '1px solid var(--border)',
      padding: '16px 24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      background: 'rgba(8,9,12,0.95)',
      backdropFilter: 'blur(16px)',
      zIndex: 100,
    }}>
      {/* Left: logo */}
      <button
        onClick={onReset}
        style={{
          background: 'none', border: 'none', cursor: 'pointer', padding: 0,
          display: 'flex', alignItems: 'baseline', gap: 12,
        }}
      >
        <span style={{
          fontFamily: 'var(--font-display)',
          fontSize: '1.4rem',
          color: 'var(--california-gold)',
          letterSpacing: '-0.02em',
        }}>
          BearCourses
        </span>
        <span style={{
          fontFamily: 'var(--font-mono)',
          fontSize: '0.6rem',
          color: 'var(--text-secondary)',
          letterSpacing: '0.12em',
          textTransform: 'uppercase',
        }}>
          UC Berkeley · Course Intelligence
        </span>
      </button>

      {/* Right: profile info + status + clock */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
        {parsedProfile && (
          <div style={{
            display: 'flex', gap: 20,
            fontFamily: 'var(--font-mono)',
            fontSize: '0.68rem',
          }}>
            <span style={{ color: 'var(--california-gold)' }}>{parsedProfile.major}</span>
            <span style={{ color: 'var(--text-secondary)' }}>Cat. {parsedProfile.catalogYear}</span>
            <span style={{ color: 'var(--text-secondary)' }}>{parsedProfile.completedUnits} units</span>
          </div>
        )}

        {/* Status pill */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 7,
          padding: '5px 12px',
          border: '1px solid var(--border)',
          borderRadius: 20,
          background: 'var(--bg-panel)',
        }}>
          <span style={{
            width: 6, height: 6, borderRadius: '50%',
            background: dotColor,
            display: 'inline-block',
            boxShadow: phase === 'running' ? `0 0 6px ${dotColor}` : 'none',
            animation: phase === 'running' ? 'pulse-gold 1.4s ease-in-out infinite' : 'none',
          }} />
          <span style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '0.62rem',
            color: 'var(--text-secondary)',
            textTransform: 'uppercase',
            letterSpacing: '0.1em',
          }}>
            {statusLabel}
          </span>
        </div>

        {/* Clock — steady, no flash */}
        <span style={{
          fontFamily: 'var(--font-mono)',
          fontSize: '0.65rem',
          color: 'var(--text-secondary)',
          opacity: 0.5,
          minWidth: 64,
          textAlign: 'right',
        }}>
          {time}
        </span>
      </div>
    </header>
  )
}
