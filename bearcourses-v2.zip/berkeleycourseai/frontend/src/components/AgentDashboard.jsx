import { useEffect, useState } from 'react'

// Tier structure for the orchestration tree
const TIERS = [
  {
    id: 0,
    label: 'Input',
    agents: [{ id: 'parse-pdf', name: 'PDF Parser', sub: 'degree progress · completed courses · catalog year', icon: '◈' }],
  },
  {
    id: 1,
    label: 'Candidate Filter',
    agents: [
      { id: 'requirements', name: 'Req. Mapper', sub: 'guide.berkeley.edu · catalog year matching · double-count map', icon: '◉' },
      { id: 'courses', name: 'Course Catalog', sub: 'classes.berkeley.edu · time slots · instructors · units', icon: '◉' },
    ],
    note: 'Intersect → prune to candidates only',
  },
  {
    id: 2,
    label: 'Enrichment',
    agents: [
      { id: 'berkeleytime', name: 'Berkeley Time', sub: 'GPA distributions · grade curves · enrollment trends', icon: '◎' },
      { id: 'rmp', name: 'RateMyProf', sub: 'professor ratings · difficulty · would take again', icon: '◎' },
      { id: 'scheduler', name: 'Scheduler', sub: 'calcentral session · conflict detection · time math', icon: '◎' },
      { id: 'reddit', name: 'Community', sub: 'r/berkeley · dated snippets · paraphrased sentiment', icon: '◎' },
    ],
    note: 'All parallel · candidates only · graceful degradation',
  },
  {
    id: 3,
    label: 'Synthesis',
    agents: [{ id: 'score', name: 'Orchestrator', sub: 'weighted scoring · double-count boost · ranking · schedule build', icon: '◈' }],
  },
]

const STATUS = {
  idle:    { color: '#2d3748', label: 'waiting' },
  running: { color: '#FDB515', label: 'running' },
  done:    { color: '#4caf6e', label: 'done' },
  error:   { color: '#e05252', label: 'error' },
  skipped: { color: '#2d3748', label: 'skipped' },
}

// Example schedule shown while agents run
const EXAMPLE_COURSES = [
  { code: 'MUSIC 27', title: 'Music of the World', time: 'MWF 10–11', units: 3, req: 'Arts & Lit', rmp: 4.8, gpa: 3.71, double: true, doubleReq: 'International', color: '#FDB515' },
  { code: 'ESPM 50AC', title: 'Society & Environment', time: 'TuTh 11–12:30', units: 4, req: 'Biological Sci', rmp: 4.3, gpa: 3.52, double: false, color: '#5b9bd5' },
  { code: 'INTEGBI 35AC', title: 'Human Physiology', time: 'MWF 2–3', units: 3, req: 'Biological Sci', rmp: 3.9, gpa: 3.44, double: false, color: '#a78bfa' },
  { code: 'PHILOS 2', title: 'Individual & Society', time: 'TuTh 2–3:30', units: 4, req: 'Social & Behavioral', rmp: 4.6, gpa: 3.63, double: true, doubleReq: 'American Cultures', color: '#4caf6e' },
  { code: 'HISTORY 7B', title: 'US History', time: 'MWF 9–10', units: 4, req: 'Historical Studies', rmp: 4.1, gpa: 3.38, double: false, color: '#f97316' },
]

export default function AgentDashboard({ agentStates, parsedProfile }) {
  const [elapsed, setElapsed] = useState(0)
  const [startTime] = useState(Date.now())
  const [scheduleVisible, setScheduleVisible] = useState(false)

  useEffect(() => {
    const t = setInterval(() => setElapsed(Math.floor((Date.now() - startTime) / 100) / 10), 100)
    return () => clearInterval(t)
  }, [startTime])

  useEffect(() => {
    const t = setTimeout(() => setScheduleVisible(true), 1200)
    return () => clearTimeout(t)
  }, [])

  const totalAgents = TIERS.flatMap(t => t.agents).length
  const doneAgents = Object.values(agentStates).filter(a => a?.status === 'done').length
  const pct = Math.round((doneAgents / totalAgents) * 100)

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', paddingTop: 40, display: 'grid', gridTemplateColumns: '1fr 380px', gap: 40, alignItems: 'start' }}>

      {/* LEFT: orchestration tree */}
      <div>
        {/* Header row */}
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 32 }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.9rem', color: 'var(--text-primary)', letterSpacing: '-0.025em', lineHeight: 1, marginBottom: 6 }}>
              Analyzing your options
            </h2>
            {parsedProfile && (
              <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-secondary)' }}>
                <span style={{ color: 'var(--california-gold)' }}>{parsedProfile.major}</span>
                {' · '}{parsedProfile.completedUnits} units completed
                {parsedProfile.unmetRequirements && ` · ${Object.keys(parsedProfile.unmetRequirements).length} reqs to fill`}
              </p>
            )}
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '2.4rem', color: 'var(--california-gold)', letterSpacing: '-0.05em', lineHeight: 1 }}>
              {elapsed.toFixed(1)}<span style={{ fontSize: '1rem', opacity: 0.5, marginLeft: 2 }}>s</span>
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-secondary)', marginTop: 3 }}>
              {doneAgents}/{totalAgents} agents · {pct}%
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div style={{ height: 1, background: 'var(--border)', borderRadius: 1, marginBottom: 36, overflow: 'hidden' }}>
          <div style={{ height: '100%', background: 'var(--california-gold)', width: `${pct}%`, transition: 'width 0.6s ease', borderRadius: 1 }} />
        </div>

        {/* Tier tree */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {TIERS.map((tier, ti) => {
            const tierDone = tier.agents.every(a => agentStates[a.id]?.status === 'done')
            const tierRunning = tier.agents.some(a => agentStates[a.id]?.status === 'running')

            return (
              <div key={tier.id}>
                {/* Tier label + connector */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0 }}>
                    {ti > 0 && <div style={{ width: 1, height: 20, background: tierDone ? 'var(--california-gold)' : 'var(--border)', transition: 'background 0.6s' }} />}
                    <div style={{
                      width: 8, height: 8, borderRadius: '50%',
                      background: tierDone ? 'var(--california-gold)' : tierRunning ? 'var(--california-gold)' : 'var(--border)',
                      boxShadow: tierRunning ? '0 0 8px var(--california-gold)' : 'none',
                      animation: tierRunning ? 'pulse-gold 1.2s ease-in-out infinite' : 'none',
                      transition: 'background 0.4s',
                      flexShrink: 0,
                    }} />
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.58rem', textTransform: 'uppercase', letterSpacing: '0.14em', color: 'var(--text-secondary)' }}>
                      Tier {tier.id}
                    </span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: tierDone ? 'var(--california-gold)' : 'var(--text-primary)', fontWeight: 500 }}>
                      {tier.label}
                    </span>
                    {tier.note && (
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-secondary)', opacity: 0.6 }}>
                        — {tier.note}
                      </span>
                    )}
                  </div>
                </div>

                {/* Agent cards in this tier */}
                <div style={{
                  marginLeft: 24,
                  paddingLeft: 20,
                  borderLeft: `1px solid ${tierDone ? 'rgba(253,181,21,0.3)' : 'var(--border)'}`,
                  marginBottom: 4,
                  display: 'grid',
                  gridTemplateColumns: tier.agents.length > 2 ? 'repeat(2, 1fr)' : tier.agents.length === 1 ? '1fr' : 'repeat(2, 1fr)',
                  gap: 8,
                  transition: 'border-color 0.5s',
                }}>
                  {tier.agents.map(agent => (
                    <AgentCard key={agent.id} agent={agent} state={agentStates[agent.id] || { status: 'idle' }} />
                  ))}
                </div>

                {/* Candidate count message between tier 1 and 2 */}
                {tier.id === 1 && agentStates['courses']?.candidateCount && (
                  <div style={{
                    marginLeft: 24, paddingLeft: 20,
                    marginBottom: 4,
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.68rem',
                    color: 'var(--california-gold)',
                    borderLeft: '1px solid rgba(253,181,21,0.3)',
                    padding: '8px 0 8px 20px',
                    animation: 'fadeUp 0.4s ease forwards',
                  }}>
                    ↓ {agentStates['courses'].candidateCount} candidates identified
                    {agentStates['courses'].doubleCountCount > 0 &&
                      <span style={{ color: 'var(--green-signal)', marginLeft: 12 }}>· {agentStates['courses'].doubleCountCount} double-count opportunities</span>
                    }
                  </div>
                )}

                {/* Bottom spacer */}
                <div style={{ height: ti < TIERS.length - 1 ? 4 : 0 }} />
              </div>
            )
          })}
        </div>
      </div>

      {/* RIGHT: example schedule preview */}
      <div style={{
        position: 'sticky', top: 100,
        opacity: scheduleVisible ? 1 : 0,
        transform: scheduleVisible ? 'translateY(0)' : 'translateY(24px)',
        transition: 'opacity 0.7s ease, transform 0.7s ease',
      }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.14em', marginBottom: 12 }}>
          Example output ·  preview
        </div>

        {/* Weekly calendar strip */}
        <WeeklyCalendar courses={EXAMPLE_COURSES} />

        {/* Course list */}
        <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {EXAMPLE_COURSES.map((c, i) => (
            <ExampleCourseRow key={c.code} course={c} index={i} />
          ))}
        </div>

        <div style={{ marginTop: 14, padding: '10px 14px', background: 'var(--bg-panel)', borderRadius: 8, border: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: '0.65rem' }}>
            <span style={{ color: 'var(--text-secondary)' }}>Total units</span>
            <span style={{ color: 'var(--california-gold)' }}>18</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: '0.65rem', marginTop: 4 }}>
            <span style={{ color: 'var(--text-secondary)' }}>Avg GPA</span>
            <span style={{ color: 'var(--green-signal)' }}>3.54</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: '0.65rem', marginTop: 4 }}>
            <span style={{ color: 'var(--text-secondary)' }}>Double counts</span>
            <span style={{ color: 'var(--green-signal)' }}>2 courses</span>
          </div>
        </div>

        <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.58rem', color: 'var(--text-secondary)', opacity: 0.45, marginTop: 10, textAlign: 'center', lineHeight: 1.6 }}>
          Sample data for illustration — your results<br />will reflect your actual requirements & schedule
        </p>
      </div>
    </div>
  )
}

function AgentCard({ agent, state }) {
  const s = STATUS[state.status] || STATUS.idle
  const isRunning = state.status === 'running'
  const isDone = state.status === 'done'

  return (
    <div style={{
      background: isDone ? 'rgba(76,175,110,0.04)' : isRunning ? 'rgba(253,181,21,0.04)' : 'var(--bg-card)',
      border: `1px solid ${isDone ? 'rgba(76,175,110,0.18)' : isRunning ? 'rgba(253,181,21,0.25)' : 'var(--border)'}`,
      borderRadius: 8,
      padding: '12px 14px',
      transition: 'all 0.3s',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 5 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: '0.7rem', opacity: isDone ? 1 : 0.4, color: s.color }}>{agent.icon}</span>
          <span style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: '0.8rem', color: 'var(--text-primary)' }}>
            {agent.name}
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          {isRunning && (
            <span style={{ width: 5, height: 5, borderRadius: '50%', background: s.color, display: 'inline-block', animation: 'pulse-gold 0.9s infinite' }} />
          )}
          {isDone && <span style={{ color: 'var(--green-signal)', fontSize: '0.7rem' }}>✓</span>}
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.58rem', color: s.color, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
            {s.label}
          </span>
        </div>
      </div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.62rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
        {agent.sub}
      </div>
      {state.message && (
        <div style={{
          marginTop: 7,
          fontFamily: 'var(--font-mono)',
          fontSize: '0.62rem',
          color: state.status === 'error' ? '#e05252' : 'var(--text-mono)',
          background: 'rgba(0,0,0,0.3)',
          borderRadius: 4,
          padding: '5px 8px',
          borderLeft: `2px solid ${s.color}`,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
        }}>
          {/* Suppress raw API errors from showing — just show count/done messages */}
          {state.status === 'error' ? 'Continuing without this signal' : state.message}
        </div>
      )}
    </div>
  )
}

// Days in the week calendar
const DAYS = ['M', 'Tu', 'W', 'Th', 'F']
const HOURS = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17]

function parseSlot(timeStr) {
  // "MWF 10–11" → { days: ['M','W','F'], start: 10, end: 11 }
  if (!timeStr) return null
  const match = timeStr.match(/([A-Za-z]+)\s+(\d+)(?::(\d+))?[–-](\d+)/)
  if (!match) return null
  const [, daysStr, startH, , endH] = match
  const days = []
  if (daysStr.includes('MWF') || (daysStr.includes('M') && daysStr.includes('W') && daysStr.includes('F'))) {
    days.push('M', 'W', 'F')
  } else if (daysStr === 'TuTh' || daysStr === 'TTh') {
    days.push('Tu', 'Th')
  } else if (daysStr === 'MW') {
    days.push('M', 'W')
  } else {
    if (daysStr.includes('M')) days.push('M')
    if (daysStr.includes('Tu') || (daysStr.includes('T') && !daysStr.includes('Th'))) days.push('Tu')
    if (daysStr.includes('W')) days.push('W')
    if (daysStr.includes('Th')) days.push('Th')
    if (daysStr.includes('F')) days.push('F')
  }
  return { days, start: parseInt(startH), end: parseInt(endH) }
}

function WeeklyCalendar({ courses }) {
  const minH = 8, maxH = 18
  const totalH = maxH - minH

  return (
    <div style={{
      background: 'var(--bg-card)',
      border: '1px solid var(--border)',
      borderRadius: 10,
      overflow: 'hidden',
      padding: '12px 12px 8px',
    }}>
      {/* Day headers */}
      <div style={{ display: 'grid', gridTemplateColumns: '28px repeat(5, 1fr)', marginBottom: 6 }}>
        <div />
        {DAYS.map(d => (
          <div key={d} style={{ textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: '0.58rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{d}</div>
        ))}
      </div>

      {/* Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '28px repeat(5, 1fr)', position: 'relative', height: 160 }}>
        {/* Hour lines */}
        {HOURS.map(h => (
          <div key={h} style={{
            gridColumn: '1 / -1',
            position: 'absolute',
            top: `${((h - minH) / totalH) * 100}%`,
            left: 28,
            right: 0,
            height: 1,
            background: 'var(--border)',
            opacity: 0.4,
          }} />
        ))}
        {/* Hour labels */}
        {[9, 11, 13, 15, 17].map(h => (
          <div key={h} style={{
            position: 'absolute',
            top: `${((h - minH) / totalH) * 100}%`,
            left: 0,
            width: 24,
            fontFamily: 'var(--font-mono)',
            fontSize: '0.5rem',
            color: 'var(--text-secondary)',
            opacity: 0.5,
            transform: 'translateY(-50%)',
            textAlign: 'right',
          }}>
            {h > 12 ? h - 12 : h}
          </div>
        ))}

        {/* Course blocks */}
        {courses.map(course => {
          const slot = parseSlot(course.time)
          if (!slot) return null
          return slot.days.map(day => {
            const col = DAYS.indexOf(day)
            if (col < 0) return null
            const topPct = ((slot.start - minH) / totalH) * 100
            const heightPct = ((slot.end - slot.start) / totalH) * 100
            return (
              <div key={course.code + day} style={{
                position: 'absolute',
                top: `${topPct}%`,
                height: `${heightPct}%`,
                left: `calc(28px + ${col} * ((100% - 28px) / 5) + 2px)`,
                width: `calc((100% - 28px) / 5 - 4px)`,
                background: course.color + '22',
                borderLeft: `2px solid ${course.color}`,
                borderRadius: 3,
                padding: '3px 5px',
                overflow: 'hidden',
              }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.5rem', color: course.color, fontWeight: 600, lineHeight: 1.2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {course.code}
                </div>
              </div>
            )
          })
        })}
      </div>
    </div>
  )
}

function ExampleCourseRow({ course, index }) {
  return (
    <div style={{
      background: 'var(--bg-card)',
      border: '1px solid var(--border)',
      borderRadius: 8,
      padding: '10px 14px',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      animation: `fadeUp 0.4s ease ${index * 80}ms both`,
    }}>
      <div style={{ width: 3, height: 32, borderRadius: 2, background: course.color, flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: course.color, fontWeight: 600 }}>{course.code}</span>
          {course.double && (
            <span style={{ background: 'rgba(76,175,110,0.12)', border: '1px solid rgba(76,175,110,0.25)', borderRadius: 3, padding: '1px 6px', fontFamily: 'var(--font-mono)', fontSize: '0.52rem', color: 'var(--green-signal)' }}>
              2× count
            </span>
          )}
        </div>
        <div style={{ fontFamily: 'var(--font-body)', fontSize: '0.72rem', color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{course.title}</div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.58rem', color: 'var(--text-secondary)', marginTop: 1 }}>{course.time} · {course.units} units</div>
      </div>
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--green-signal)' }}>{course.gpa.toFixed(2)}</div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.58rem', color: 'var(--text-secondary)' }}>RMP {course.rmp}</div>
      </div>
    </div>
  )
}
