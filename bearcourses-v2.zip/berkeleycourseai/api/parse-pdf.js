import Anthropic from '@anthropic-ai/sdk'
import formidable from 'formidable'
import fs from 'fs'
import pdfParse from 'pdf-parse'

export const config = { api: { bodyParser: false } }

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  try {
    const form = formidable({ maxFileSize: 10 * 1024 * 1024 })
    const [fields, files] = await form.parse(req)
    const pdfFile = Array.isArray(files.pdf) ? files.pdf[0] : files.pdf
    const major = Array.isArray(fields.major) ? fields.major[0] : (fields.major ?? 'Unknown')

    if (!pdfFile) return res.status(400).json({ error: 'No PDF uploaded' })

    // Extract text
    const pdfBuffer = fs.readFileSync(pdfFile.filepath)
    let rawText = ''
    try {
      const pdfData = await pdfParse(pdfBuffer)
      rawText = pdfData.text
    } catch {
      // If pdf-parse fails, return a stub and let the pipeline continue
      return res.status(200).json(makeStub(major, ''))
    }

    // If no API key configured, return a labelled stub
    if (!process.env.ANTHROPIC_API_KEY) {
      console.warn('No ANTHROPIC_API_KEY set — returning stub profile')
      return res.status(200).json(makeStub(major, rawText))
    }

    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

    let parsed
    try {
      const response = await client.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        system: 'You are a UC Berkeley degree progress parser. Extract structured data from CalCentral degree progress PDF text. Return ONLY valid JSON with no markdown or preamble.',
        messages: [{
          role: 'user',
          content: `Parse this CalCentral degree progress PDF for major: "${major}".

Return this exact JSON structure:
{
  "completedCourses": ["CS 61A", "MATH 1A"],
  "catalogYear": "2022-23",
  "major": "${major}",
  "completedUnits": 60,
  "unmetRequirements": {
    "Arts & Literature": ["MUSIC", "ART", "THEATER", "ESPM"],
    "Biological Science": ["BIO", "MCELLBI", "INTEGBI", "ESPM", "NUSCTX"],
    "Historical Studies": ["HISTORY", "GEOG", "ANTHRO"],
    "International Studies": ["any course with international designation"],
    "Physical Science": ["PHYSICS", "CHEM", "EPS", "ASTRON"],
    "Quantitative Reasoning": ["MATH", "STAT", "COMPSCI"],
    "Reading & Composition": ["COLWRIT", "ENGLISH"],
    "Social & Behavioral": ["SOCIOL", "PSYCH", "POLS", "ECON"],
    "Philosophy & Values": ["PHILOS", "UGIS", "ESPM"]
  }
}

Adjust unmetRequirements based on what the PDF shows as already satisfied.
If you cannot parse a section, use sensible Berkeley defaults.

PDF TEXT (first 6000 chars):
${rawText.slice(0, 6000)}`
        }]
      })

      const content = response.content[0].text
      const clean = content.replace(/```json|```/g, '').trim()
      const jsonMatch = clean.match(/\{[\s\S]*\}/)
      parsed = JSON.parse(jsonMatch ? jsonMatch[0] : clean)
    } catch (parseErr) {
      console.error('Claude parse error:', parseErr)
      parsed = makeStub(major, rawText)
    }

    // Ensure required fields exist
    parsed.major = parsed.major || major
    parsed.completedCourses = parsed.completedCourses || []
    parsed.completedUnits = parsed.completedUnits || 0
    parsed.catalogYear = parsed.catalogYear || getCurrentCatalogYear()
    parsed.unmetRequirements = parsed.unmetRequirements || defaultUnmetReqs()

    res.status(200).json(parsed)
  } catch (err) {
    console.error('parse-pdf fatal error:', err)
    // Always return 200 with a stub — pipeline gracefully continues
    res.status(200).json(makeStub('Unknown', ''))
  }
}

function makeStub(major, rawText) {
  // Extract course codes from raw text if possible (regex fallback)
  const coursePattern = /([A-Z]{2,10})\s+(\d{1,3}[A-Z]?)/g
  const completedCourses = []
  let match
  while ((match = coursePattern.exec(rawText)) !== null) {
    const code = `${match[1]} ${match[2]}`
    if (!completedCourses.includes(code)) completedCourses.push(code)
  }

  return {
    major,
    catalogYear: getCurrentCatalogYear(),
    completedCourses: completedCourses.slice(0, 50),
    completedUnits: completedCourses.length * 3,
    unmetRequirements: defaultUnmetReqs(),
    _stub: true, // flag so UI can show a soft warning
  }
}

function getCurrentCatalogYear() {
  const now = new Date()
  const year = now.getFullYear()
  const month = now.getMonth()
  const startYear = month >= 7 ? year : year - 1
  return `${startYear}-${String(startYear + 1).slice(2)}`
}

function defaultUnmetReqs() {
  return {
    'Arts & Literature': ['MUSIC', 'ART', 'THEATER', 'FILM', 'ESPM', 'ITALIAN', 'FRENCH'],
    'Biological Science': ['BIO', 'MCELLBI', 'INTEGBI', 'ESPM', 'NUSCTX', 'PMB'],
    'Historical Studies': ['HISTORY', 'GEOG', 'ANTHRO', 'ESPM', 'AFRICAM'],
    'International Studies': ['GEOG', 'HISTORY', 'POLS', 'ECON', 'ANTHRO'],
    'Physical Science': ['PHYSICS', 'CHEM', 'EPS', 'ASTRON', 'MATERI'],
    'Quantitative Reasoning': ['MATH', 'STAT', 'COMPSCI'],
    'Reading & Composition': ['COLWRIT', 'ENGLISH'],
    'Social & Behavioral Sciences': ['SOCIOL', 'PSYCH', 'POLS', 'ECON', 'ESPM'],
    'Philosophy & Values': ['PHILOS', 'UGIS', 'ESPM', 'ETHSTD'],
  }
}
